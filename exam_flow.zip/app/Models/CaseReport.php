<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class CaseReport extends Model
{
    use HasFactory;

    protected $guarded = ['id'];

    protected $casts = [
        'is_detailed' => 'boolean',
    ];

    // 様式5（詳細）の対象は運用上 No.1・No.2 に固定されている
    public const DETAILED_CASE_NOS = [1, 2];

    public function exam()
    {
        return $this->belongsTo(Exam::class);
    }

    public function getVisitTypeLabelAttribute(): ?string
    {
        return match ($this->visit_type) {
            'outpatient' => '外来',
            'inpatient'  => '入院',
            default      => null,
        };
    }

    // 保存前に case_no に応じて is_detailed を自動設定するヘルパー
    // （Controller側で明示的に呼ぶ想定。モデルイベントでの自動化はあえて避け、
    //   保存経路を追いやすくする）
    public static function isDetailedCaseNo(int $caseNo): bool
    {
        return in_array($caseNo, self::DETAILED_CASE_NOS, true);
    }
}
