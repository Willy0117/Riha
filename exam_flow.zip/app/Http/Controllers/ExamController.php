<?php

namespace App\Http\Controllers;

use Inertia\Inertia;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Auth;
use Illuminate\Validation\Rule;

use App\Models\Exam;
use App\Models\ExamDocument;
use App\Models\CaseReport;
use App\Models\InstructorCycle;
use App\Models\Member;
use App\Models\Invoice;

use App\Services\FileService;

class ExamController extends Controller
{
    // ──────────────────────────────────────────
    // 一覧兼メイン画面
    // [今回全面修正] PdfUploads/Create.vue と同じ構成に合わせる。
    // 証明書・推薦状・症例報告は、この画面を開いた時点で用意される「下書き（draft）」の
    // Exam に対して、それぞれ個別に保存されていく。全て揃って初めて
    // 「受験申込を行う」（status: draft → submitted）を押せる。
    // ──────────────────────────────────────────
    public function index()
    {
        $member = Auth::user()->member;

        $currentCycle = InstructorCycle::currentlyRecruiting();
        $eligibility = $this->checkEligibility($member);

        $draftExam = null;

        // 募集中かつ受験資格を満たしていれば、下書きのApplicationを用意する（無ければ作る）
        if ($currentCycle && $eligibility['all_ok']) {
            $draftExam = Exam::firstOrCreate(
                [
                    'member_id' => $member->id,
                    'exam_round' => $currentCycle->exam_round,
                ],
                [
                    'route' => 'A',
                    'last_name' => $member->last_name,
                    'first_name' => $member->first_name,
                    'last_name_kana' => $member->last_name_kana,
                    'first_name_kana' => $member->first_name_kana,
                    'birthdate' => $member->birthdate,
                    'gender' => $member->gender,
                    'occupation' => null,
                    'workplace' => null,
                    'email' => $member->email,
                    'tel' => $member->tel,
                    'member_code_snapshot' => $member->code,
                    'member_joined_at_snapshot' => $this->joinedAtSnapshot($member),
                    'status' => 'draft',
                ]
            );

            if ($draftExam->wasRecentlyCreated) {
                $this->ensureCaseReportRows($draftExam);
            }

            $draftExam->load(['documents', 'caseReports']);
        }

        // 過去（今回以外）の申請履歴
        $pastExams = Exam::with(['instructorCycle'])
            ->where('member_id', $member->id)
            ->when($draftExam, fn ($q) => $q->where('id', '!=', $draftExam->id))
            ->orderByDesc('created_at')
            ->get();

        return Inertia::render('Exams/Index', [
            'member' => $member,
            'currentCycle' => $currentCycle,
            'eligibility' => $eligibility,
            'exam' => $draftExam,
            'pastExams' => $pastExams,
        ]);
    }

    // ──────────────────────────────────────────
    // 申請者情報・ルートの保存（下書き状態のときだけ編集可能）
    // ──────────────────────────────────────────
    public function updateInfo(Request $request, Exam $exam)
    {
        $this->authorizeOwnDraft($exam);

        $data = $request->validate([
            'route' => ['required', Rule::in(['A', 'B'])],
            'last_name' => 'required|string|max:100',
            'first_name' => 'required|string|max:100',
            'last_name_kana' => 'nullable|string|max:100',
            'first_name_kana' => 'nullable|string|max:100',
            'birthdate' => 'nullable|date',
            'gender' => 'nullable|in:male,female,other',
            'occupation' => 'required|string|max:100',
            'workplace' => 'required|string|max:255',
            'department' => 'nullable|string|max:255',
            'position' => 'nullable|string|max:100',
            'workplace_address' => 'nullable|string|max:255',
            'email' => 'required|email|max:255',
            'tel' => 'nullable|string|max:30',
        ]);

        $exam->update($data);

        return back()->with('success', '申請者情報を保存しました。');
    }

    // ──────────────────────────────────────────
    // 証明書・推薦状の個別アップロード
    // [PdfUploadControllerと同じ考え方] 1ファイルごとにその場でアップロード・保存する。
    // 同じtypeが既にあれば置き換える（再アップロード＝差し替え）。
    // ──────────────────────────────────────────
    public function uploadDocument(Request $request, Exam $exam, FileService $fileService)
    {
        $this->authorizeOwnDraft($exam);

        $validated = $request->validate([
            'type' => ['required', Rule::in(['certificate', 'recome1', 'recome2'])],
            'file' => 'required|file|mimes:pdf|max:10240',
        ]);

        [$filePath, $thumbnailPath] = $fileService->storeUploadedFile(
            $request->file('file'),
            'exam_documents'
        );

        // 差し替え：同じtypeの既存レコードがあれば削除してから作り直す
        $exam->documents()->where('type', $validated['type'])->delete();

        $document = ExamDocument::create([
            'exam_id' => $exam->id,
            'type' => $validated['type'],
            'file_path' => $filePath,
            'thumbnail_path' => $thumbnailPath,
        ]);

        return back()->with('success', 'アップロードしました。');
    }

    public function deleteDocument(Exam $exam, ExamDocument $document)
    {
        $this->authorizeOwnDraft($exam);
        abort_unless($document->exam_id === $exam->id, 403);

        $document->delete();

        return back()->with('success', '削除しました。');
    }

    // ──────────────────────────────────────────
    // 症例報告1件の保存（No.1〜10、カード単位でその場保存）
    // ──────────────────────────────────────────
    public function updateCaseReport(Request $request, Exam $exam, CaseReport $caseReport)
    {
        $this->authorizeOwnDraft($exam);
        abort_unless($caseReport->exam_id === $exam->id, 403);

        $data = $request->validate([
            'facility' => 'nullable|string|max:255',
            'age' => 'nullable|integer|min:0|max:150',
            'gender' => 'nullable|in:male,female,other',
            'visit_type' => 'nullable|in:outpatient,inpatient',
            'diagnosis' => 'nullable|string|max:255',
            'current_history' => 'nullable|string',
            'past_history' => 'nullable|string',
            'rehab' => 'nullable|string',
            'future_plan' => 'nullable|string',
            'patient_profile' => 'nullable|string',
            'examination_findings' => 'nullable|string',
            'rehab_and_patient_education' => 'nullable|string',
            'discussion' => 'nullable|string',
        ]);

        if (!$caseReport->is_detailed) {
            unset(
                $data['patient_profile'],
                $data['examination_findings'],
                $data['rehab_and_patient_education'],
                $data['discussion']
            );
        }

        $caseReport->update($data);

        return back()->with('success', "症例No.{$caseReport->case_no} を保存しました。");
    }

    // ──────────────────────────────────────────
    // 受験申込の最終提出（status: draft → submitted）
    // ここでは新たなデータは受け取らない。既に個別に保存済みの内容が揃っているかだけ確認する。
    // ──────────────────────────────────────────
    public function submit(Request $request, Exam $exam)
    {
        $this->authorizeOwnDraft($exam);

        $exam->load('documents', 'caseReports');
        $missing = $this->missingRequirements($exam);

        abort_if(!empty($missing), 422, '必要な項目が揃っていません：' . implode('、', $missing));

        $exam->status = 'submitted';
        $exam->applied_at = now();
        $exam->save();

        return redirect()->route('exams.index')
            ->with('success', '受験申込を受け付けました。事務局からの連絡をお待ちください。');
    }

    public function show(Exam $exam)
    {
        $member = Auth::user()->member;
        abort_unless($exam->member_id === $member->id, 403);

        $exam->load(['documents', 'caseReports', 'instructorCycle']);

        return Inertia::render('Exams/Show', [
            'exam' => $exam,
        ]);
    }

    // ──────────────────────────────────────────
    // Private
    // ──────────────────────────────────────────

    private function authorizeOwnDraft(Exam $exam): void
    {
        $member = Auth::user()->member;
        abort_unless($exam->member_id === $member->id, 403);
        abort_unless($exam->status === 'draft', 422, '提出済みの申請は編集できません。');
    }

    // 下書き作成時、10件の空の症例報告レコードを先に用意しておく
    // （route=Bで確定した場合にだけ入力必須になるが、レコード自体はroute確定前から存在させ、
    //   保存のたびに作り直さず「同じ10件を編集していく」形にする）
    private function ensureCaseReportRows(Exam $exam): void
    {
        for ($caseNo = 1; $caseNo <= 10; $caseNo++) {
            CaseReport::firstOrCreate(
                ['exam_id' => $exam->id, 'case_no' => $caseNo],
                ['is_detailed' => CaseReport::isDetailedCaseNo($caseNo)]
            );
        }
    }

    // 提出前チェック：ルートに応じて必要な書類・症例報告が揃っているか
    private function missingRequirements(Exam $exam): array
    {
        $missing = [];

        if (empty($exam->last_name) || empty($exam->occupation) || empty($exam->workplace) || empty($exam->email)) {
            $missing[] = '申請者情報';
        }

        $types = $exam->documents->pluck('type')->all();

        if ($exam->route === 'A') {
            if (!in_array('certificate', $types)) $missing[] = '様式2（証明書）';
            if (!in_array('recome1', $types)) $missing[] = '様式3-1（推薦状）';
        } else {
            if (!in_array('recome2', $types)) $missing[] = '様式3-2（推薦状）';

            $incomplete = $exam->caseReports->contains(function (CaseReport $cr) {
                $basicMissing = !$cr->facility || !$cr->diagnosis;
                $detailMissing = $cr->is_detailed && (!$cr->patient_profile || !$cr->discussion);
                return $basicMissing || $detailMissing;
            });

            if ($incomplete) $missing[] = '自験例報告書（未入力の症例があります）';
        }

        return $missing;
    }

    private function joinedAtSnapshot(Member $member): ?string
    {
        $firstFiscalYear = $this->firstFiscalYear($member);
        return $firstFiscalYear ? "{$firstFiscalYear}-12-01" : null;
    }

    private function firstFiscalYear(Member $member): ?int
    {
        return Invoice::where('member_id', $member->id)
            ->where('annual_fee', '>', 0)
            ->min('fiscal_year');
    }

    private function checkEligibility(Member $member): array
    {
        $errors = [];

        if ($member->status_id === Member::STATUS_WITHDRAWN) {
            $errors[] = '退会済みのため申請できません。';
        }

        $firstFiscalYear = $this->firstFiscalYear($member);

        $today = now();
        $currentFiscalYear = $today->month === 12 ? $today->year : $today->year - 1;

        if (!$firstFiscalYear || ($currentFiscalYear - $firstFiscalYear) < 2) {
            $errors[] = '入会から直近2年度以上継続して正会員である必要があります。';
        }

        if (method_exists($member, 'isAnnualFeePaid') && !$member->isAnnualFeePaid()) {
            $errors[] = '年会費が未納のため申請できません。';
        }

        return [
            'all_ok' => empty($errors),
            'errors' => $errors,
            'message' => implode(' ', $errors),
        ];
    }
}
