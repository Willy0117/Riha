<template>
  <AppLayout>
    <template #header>指導士資格認定試験 受験申込</template>

    <div class="max-w-none mx-auto p-8 flex flex-col gap-6 font-sans text-[#1a1a2e]">

      <!-- 募集回・受験資格の状況 -->
      <div class="bg-white rounded-xl border border-gray-200 p-6">
        <div class="grid grid-cols-1 md:grid-cols-4 gap-3">
          <div class="border border-gray-300 rounded-lg px-4 py-2.5">
            <p class="flex items-center gap-1.5 text-sm text-gray-500 mb-1">
              <Calendar class="w-3.5 h-3.5 text-gray-400" /> 募集回
            </p>
            <p class="text-lg font-bold text-gray-900">
              <template v-if="currentCycle">第{{ currentCycle.exam_round }}回</template>
              <template v-else>現在募集中の回はありません</template>
            </p>
          </div>

          <div v-if="currentCycle" class="bg-orange-50 rounded-lg px-4 py-2.5">
            <p class="flex items-center gap-1.5 text-sm text-orange-500 font-semibold mb-1">
              <Clock class="w-3.5 h-3.5 text-orange-400" /> 申請受付期間
            </p>
            <p class="text-base font-bold text-orange-600">
              {{ dayjs(currentCycle.application_start).format('YYYY-MM-DD') }}
              〜
              {{ currentCycle.application_end ? dayjs(currentCycle.application_end).format('YYYY-MM-DD') : '未定' }}
            </p>
          </div>

          <div class="md:col-span-2 border border-gray-300 rounded-lg px-4 py-2.5">
            <p class="text-sm text-gray-500 mb-1.5">受験資格（会員要件）</p>
            <span class="inline-flex items-center gap-1 text-xs px-2 py-1 rounded-full"
              :class="eligibility.all_ok ? 'bg-emerald-50 text-emerald-700' : 'bg-red-50 text-red-700'">
              <CheckCircle2 v-if="eligibility.all_ok" class="w-3.5 h-3.5" />
              <XCircle v-else class="w-3.5 h-3.5" />
              {{ eligibility.all_ok ? '要件を満たしています' : '要件未達' }}
            </span>
            <ul v-if="!eligibility.all_ok" class="mt-2 space-y-0.5">
              <li v-for="(e, i) in eligibility.errors" :key="i" class="text-xs text-red-600">・{{ e }}</li>
            </ul>
          </div>
        </div>
      </div>

      <!-- 申請済み（下書き以外）：進捗ステータス表示のみ -->
      <div v-if="exam && exam.status !== 'draft'" class="bg-white rounded-xl border border-gray-200 p-6">
        <p class="text-sm font-semibold text-gray-500 mb-5 text-center">申請の進捗状況</p>
        <div class="flex items-center mb-6">
          <template v-for="(phase, idx) in phases" :key="phase">
            <div class="flex flex-col items-center flex-1">
              <div class="w-8 h-8 rounded-full flex items-center justify-center text-sm font-semibold"
                :class="idx < currentPhaseIndex ? 'bg-emerald-500 text-white' : idx === currentPhaseIndex ? 'bg-blue-600 text-white' : 'bg-gray-200 text-gray-400'">
                <CheckCircle2 v-if="idx < currentPhaseIndex" class="w-4 h-4" />
                <span v-else>{{ idx + 1 }}</span>
              </div>
              <span class="text-xs mt-2 text-center" :class="idx === currentPhaseIndex ? 'font-bold text-gray-900' : 'text-gray-500'">{{ phase }}</span>
            </div>
            <div v-if="idx < phases.length - 1" class="flex-1 h-px bg-gray-200 -mt-6"></div>
          </template>
        </div>
        <div v-if="exam.status === 'reject'" class="bg-red-50 border border-red-200 rounded-lg p-3 text-sm text-red-700">
          今回は受験資格が認められませんでした。<span v-if="exam.reason">{{ exam.reason }}</span>
        </div>
        <div v-if="exam.exam_result === 'fail'" class="bg-red-50 border border-red-200 rounded-lg p-3 text-sm text-red-700 mt-2">
          試験の結果、今回は不合格でした。
        </div>
        <div v-if="exam.status === 'certified'" class="bg-teal-50 border border-teal-200 rounded-lg p-3 text-sm text-teal-700 mt-2">
          {{ dayjs(exam.certified_at).format('YYYY-MM-DD') }} に指導士として認定されました。
        </div>
      </div>

      <!-- 下書き：申請の準備 -->
      <template v-else-if="exam">

        <!-- 申請者情報（サマリー＋編集ダイアログ） -->
        <div class="bg-white rounded-xl border border-gray-200 p-6">
          <div class="flex items-center justify-between mb-3">
            <p class="text-sm font-semibold text-gray-500">① 申請者情報・申請ルート</p>
            <Button type="button" size="sm" variant="outline" @click="openInfoDialog">編集する</Button>
          </div>
          <div class="grid grid-cols-2 sm:grid-cols-4 gap-4 text-sm">
            <div><p class="text-gray-400 text-xs mb-0.5">ルート</p><p class="font-medium">{{ exam.route }}</p></div>
            <div><p class="text-gray-400 text-xs mb-0.5">氏名</p><p class="font-medium">{{ exam.last_name || exam.first_name ? `${exam.last_name} ${exam.first_name}` : '未入力' }}</p></div>
            <div><p class="text-gray-400 text-xs mb-0.5">職種</p><p class="font-medium">{{ exam.occupation || '未入力' }}</p></div>
            <div><p class="text-gray-400 text-xs mb-0.5">勤務先</p><p class="font-medium">{{ exam.workplace || '未入力' }}</p></div>
          </div>
        </div>

        <!-- 添付書類 -->
        <div class="bg-white rounded-xl border border-gray-200 p-6">
          <div class="flex items-center justify-between mb-3">
            <p class="text-sm font-semibold text-gray-500">② 添付書類</p>
          </div>
          <div class="space-y-2">
            <div v-for="doc in requiredDocuments" :key="doc.type"
              class="border rounded-lg p-3 flex items-center justify-between">
              <div class="flex items-center gap-2">
                <FileText class="w-4 h-4 text-gray-400" />
                <div>
                  <p class="text-sm font-medium text-gray-700">{{ doc.label }}</p>
                  <p class="text-xs" :class="documentByType(doc.type) ? 'text-emerald-600' : 'text-gray-400'">
                    {{ documentByType(doc.type) ? 'アップロード済み' : '未アップロード' }}
                  </p>
                </div>
              </div>
              <div class="flex items-center gap-2">
                <a v-if="documentByType(doc.type)" :href="`/exam-documents/${documentByType(doc.type).id}/view`" target="_blank"
                  class="text-xs text-blue-600 hover:underline">確認</a>
                <Button type="button" size="sm" variant="outline" @click="openUploadDialog(doc.type, doc.label)">
                  {{ documentByType(doc.type) ? '差し替え' : 'アップロード' }}
                </Button>
              </div>
            </div>
          </div>
        </div>

        <!-- 自験例報告書：一覧＋1件ずつ編集ダイアログ -->
        <div v-if="exam.route === 'B'" class="bg-white rounded-xl border border-gray-200 p-6">
          <p class="text-sm font-semibold text-gray-500 mb-3">③ 自験例報告書（様式4・5）10症例</p>
          <div class="grid grid-cols-2 sm:grid-cols-5 gap-2">
            <button v-for="cr in exam.case_reports" :key="cr.id" type="button"
              class="border rounded-lg p-3 text-left hover:bg-gray-50"
              :class="isCaseReportFilled(cr) ? 'border-emerald-300' : 'border-gray-200'"
              @click="openCaseReportDialog(cr)">
              <div class="flex items-center justify-between">
                <span class="text-sm font-semibold">No.{{ cr.case_no }}</span>
                <CheckCircle2 v-if="isCaseReportFilled(cr)" class="w-4 h-4 text-emerald-500" />
              </div>
              <span v-if="cr.is_detailed" class="text-[10px] px-1.5 py-0.5 rounded-full bg-purple-50 text-purple-700 mt-1 inline-block">様式5対象</span>
              <p class="text-xs text-gray-400 mt-1">{{ isCaseReportFilled(cr) ? '入力済み' : '未入力' }}</p>
            </button>
          </div>
        </div>

        <!-- 提出 -->
        <div class="bg-emerald-50 border border-emerald-200 rounded-xl p-6 flex items-center justify-between">
          <div>
            <p class="font-semibold text-emerald-800">全て揃ったら提出してください</p>
            <p v-if="missing.length > 0" class="text-sm text-red-600 mt-1">未完了：{{ missing.join('、') }}</p>
          </div>
          <Button type="button" :disabled="missing.length > 0" @click="submitApplication">受験申込を行う</Button>
        </div>
      </template>

      <!-- 過去の申請履歴 -->
      <div v-if="pastExams.length > 0" class="bg-white rounded-xl border border-gray-200 p-6">
        <p class="text-sm font-semibold text-gray-500 mb-3">過去の申請履歴</p>
        <table class="min-w-full text-sm">
          <thead><tr class="text-left text-gray-400 text-xs"><th class="pb-2">回</th><th class="pb-2">申請日</th><th class="pb-2">受験資格</th><th class="pb-2">試験結果</th></tr></thead>
          <tbody class="divide-y">
            <tr v-for="app in pastExams" :key="app.id">
              <td class="py-2">第{{ app.exam_round }}回</td>
              <td class="py-2">{{ app.applied_at ? dayjs(app.applied_at).format('YYYY-MM-DD') : '-' }}</td>
              <td class="py-2">{{ statusLabels[app.status] }}</td>
              <td class="py-2">{{ examResultLabels[app.exam_result] }}</td>
            </tr>
          </tbody>
        </table>
      </div>
    </div>

    <!-- 申請者情報 編集ダイアログ -->
    <Dialog v-model:open="infoDialogOpen">
      <DialogContent class="max-w-2xl max-h-[85vh] overflow-y-auto">
        <DialogHeader><DialogTitle>申請者情報・申請ルート</DialogTitle></DialogHeader>
        <div class="space-y-3">
          <div class="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <label class="border rounded-lg p-3 cursor-pointer text-sm" :class="infoForm.route === 'A' ? 'border-blue-500 bg-blue-50' : 'border-gray-200'">
              <input type="radio" value="A" v-model="infoForm.route" class="mr-2" />
              <span class="font-semibold">ルートA</span>：主演者・座長経験あり
            </label>
            <label class="border rounded-lg p-3 cursor-pointer text-sm" :class="infoForm.route === 'B' ? 'border-purple-500 bg-purple-50' : 'border-gray-200'">
              <input type="radio" value="B" v-model="infoForm.route" class="mr-2" />
              <span class="font-semibold">ルートB</span>：実地経験1年以上
            </label>
          </div>
          <div class="grid grid-cols-1 sm:grid-cols-3 gap-3">
            <div><InputLabel value="姓" /><TextInput v-model="infoForm.last_name" class="w-full" /></div>
            <div><InputLabel value="名" /><TextInput v-model="infoForm.first_name" class="w-full" /></div>
            <div><InputLabel value="生年月日" /><TextInput v-model="infoForm.birthdate" type="date" class="w-full" /></div>
            <div>
              <InputLabel value="性別" />
              <select v-model="infoForm.gender" class="input-field">
                <option value="male">男性</option><option value="female">女性</option><option value="other">その他</option>
              </select>
            </div>
            <div><InputLabel value="職種" /><TextInput v-model="infoForm.occupation" class="w-full" /></div>
            <div><InputLabel value="勤務先" /><TextInput v-model="infoForm.workplace" class="w-full" /></div>
            <div><InputLabel value="所属部科名" /><TextInput v-model="infoForm.department" class="w-full" /></div>
            <div><InputLabel value="役職名" /><TextInput v-model="infoForm.position" class="w-full" /></div>
            <div><InputLabel value="勤務先住所" /><TextInput v-model="infoForm.workplace_address" class="w-full" /></div>
            <div><InputLabel value="メールアドレス" /><TextInput v-model="infoForm.email" type="email" class="w-full" /></div>
            <div><InputLabel value="電話番号" /><TextInput v-model="infoForm.tel" class="w-full" /></div>
          </div>
          <div class="flex justify-end gap-2">
            <Button type="button" variant="outline" @click="infoDialogOpen = false">キャンセル</Button>
            <Button type="button" @click="saveInfo">保存する</Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>

    <!-- 書類アップロード ダイアログ（共有・使い回し） -->
    <Dialog v-model:open="uploadDialogOpen">
      <DialogContent class="max-w-md">
        <DialogHeader><DialogTitle>{{ uploadTarget.label }}</DialogTitle></DialogHeader>
        <div class="space-y-3">
          <input type="file" accept="exam/pdf" @change="onFileSelected" class="text-sm" />
          <div class="flex justify-end gap-2">
            <Button type="button" variant="outline" @click="uploadDialogOpen = false">キャンセル</Button>
            <Button type="button" :disabled="!selectedFile || uploading" @click="confirmUpload">アップロードする</Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>

    <!-- 自験例報告書 編集ダイアログ（共有・使い回し） -->
    <Dialog v-model:open="caseReportDialogOpen">
      <DialogContent class="max-w-2xl max-h-[85vh] overflow-y-auto">
        <DialogHeader><DialogTitle v-if="activeCaseReport">自験例 No.{{ activeCaseReport.case_no }}</DialogTitle></DialogHeader>
        <div v-if="activeCaseReport" class="space-y-3">
          <CaseReportForm v-model="caseReportForm" :number="activeCaseReport.case_no" :is-detailed="activeCaseReport.is_detailed" />
          <div class="flex justify-end gap-2">
            <Button type="button" variant="outline" @click="caseReportDialogOpen = false">キャンセル</Button>
            <Button type="button" @click="saveCaseReport">保存する</Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  </AppLayout>
</template>

<script setup>
import { reactive, computed, ref } from 'vue'
import { router } from '@inertiajs/vue3'
import dayjs from 'dayjs'
import AppLayout from '@/Layouts/AppLayout.vue'
import { Button } from '@/components/ui/button'
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog'
import { Calendar, Clock, CheckCircle2, XCircle, FileText } from 'lucide-vue-next'
import InputLabel from '@/Components/InputLabel.vue'
import TextInput from '@/Components/TextInput.vue'
import CaseReportForm from '@/Components/Exams/CaseReportForm.vue'

const props = defineProps({
  member: Object,
  currentCycle: Object,
  eligibility: Object,
  exam: Object,
  pastExams: Array,
})

const statusLabels = {
  draft: '下書き', submitted: '提出済み（アサイン待ち）', pending: '書類審査中',
  approved: '受験資格あり', reject: '受験資格なし', certified: '指導士認定済み',
}
const examResultLabels = { pending: '未受験・未登録', pass: '合格', fail: '不合格' }
const phases = ['申請', '書類審査', '委員長判定', '試験結果', '指導士認定']

const currentPhaseIndex = computed(() => {
  const app = props.exam
  if (!app) return 0
  if (app.status === 'certified') return 4
  if (app.exam_result === 'pass' || app.exam_result === 'fail') return 3
  if (app.status === 'approved' || app.status === 'reject') return 3
  if (app.status === 'pending') return 1
  return 0
})

// ── 申請者情報ダイアログ ──
const infoDialogOpen = ref(false)
const infoForm = reactive({
  route: 'A', last_name: '', first_name: '', last_name_kana: '', first_name_kana: '',
  birthdate: '', gender: 'male', occupation: '', workplace: '', department: '',
  position: '', workplace_address: '', email: '', tel: '',
})

const openInfoDialog = () => {
  Object.assign(infoForm, {
    route: props.exam.route ?? 'A',
    last_name: props.exam.last_name ?? '',
    first_name: props.exam.first_name ?? '',
    last_name_kana: props.exam.last_name_kana ?? '',
    first_name_kana: props.exam.first_name_kana ?? '',
    birthdate: props.exam.birthdate ?? '',
    gender: props.exam.gender ?? 'male',
    occupation: props.exam.occupation ?? '',
    workplace: props.exam.workplace ?? '',
    department: props.exam.department ?? '',
    position: props.exam.position ?? '',
    workplace_address: props.exam.workplace_address ?? '',
    email: props.exam.email ?? '',
    tel: props.exam.tel ?? '',
  })
  infoDialogOpen.value = true
}

const saveInfo = () => {
  router.post(route('exams.updateInfo', props.exam.id), infoForm, {
    preserveScroll: true,
    onSuccess: () => { infoDialogOpen.value = false },
  })
}

// ── 書類アップロードダイアログ ──
const requiredDocuments = computed(() => {
  if (!props.exam) return []
  return props.exam.route === 'A'
    ? [
        { type: 'certificate', label: '様式2：主演者・座長経験証明書' },
        { type: 'recome1', label: '様式3-1：推薦状' },
      ]
    : [
        { type: 'recome2', label: '様式3-2：推薦状' },
      ]
})

const documentByType = (type) => props.exam?.documents?.find(d => d.type === type) ?? null

const uploadDialogOpen = ref(false)
const uploadTarget = reactive({ type: '', label: '' })
const selectedFile = ref(null)
const uploading = ref(false)

const openUploadDialog = (type, label) => {
  uploadTarget.type = type
  uploadTarget.label = label
  selectedFile.value = null
  uploadDialogOpen.value = true
}

const onFileSelected = (e) => {
  selectedFile.value = e.target.files[0] ?? null
}

const confirmUpload = () => {
  if (!selectedFile.value) return
  uploading.value = true
  router.post(route('exams.uploadDocument', props.exam.id), {
    type: uploadTarget.type,
    file: selectedFile.value,
  }, {
    forceFormData: true,
    preserveScroll: true,
    onFinish: () => { uploading.value = false },
    onSuccess: () => { uploadDialogOpen.value = false },
  })
}

// ── 自験例報告書ダイアログ ──
const caseReportDialogOpen = ref(false)
const activeCaseReport = ref(null)
const caseReportForm = reactive({
  facility: '', age: '', gender: '', visit_type: '', diagnosis: '',
  current_history: '', past_history: '', rehab: '', future_plan: '',
  patient_profile: '', examination_findings: '', rehab_and_patient_education: '', discussion: '',
})

const isCaseReportFilled = (cr) => {
  const basicOk = cr.facility && cr.diagnosis
  const detailOk = !cr.is_detailed || (cr.patient_profile && cr.discussion)
  return basicOk && detailOk
}

const openCaseReportDialog = (cr) => {
  activeCaseReport.value = cr
  Object.assign(caseReportForm, {
    facility: cr.facility ?? '', age: cr.age ?? '', gender: cr.gender ?? '', visit_type: cr.visit_type ?? '',
    diagnosis: cr.diagnosis ?? '', current_history: cr.current_history ?? '', past_history: cr.past_history ?? '',
    rehab: cr.rehab ?? '', future_plan: cr.future_plan ?? '',
    patient_profile: cr.patient_profile ?? '', examination_findings: cr.examination_findings ?? '',
    rehab_and_patient_education: cr.rehab_and_patient_education ?? '', discussion: cr.discussion ?? '',
  })
  caseReportDialogOpen.value = true
}

const saveCaseReport = () => {
  router.put(route('exams.updateCaseReport', [props.exam.id, activeCaseReport.value.id]), caseReportForm, {
    preserveScroll: true,
    onSuccess: () => { caseReportDialogOpen.value = false },
  })
}

// ── 提出 ──
const missing = computed(() => {
  const app = props.exam
  if (!app) return []
  const m = []
  if (!app.last_name || !app.occupation || !app.workplace || !app.email) m.push('申請者情報')

  const types = (app.documents ?? []).map(d => d.type)
  if (app.route === 'A') {
    if (!types.includes('certificate')) m.push('様式2（証明書）')
    if (!types.includes('recome1')) m.push('様式3-1（推薦状）')
  } else {
    if (!types.includes('recome2')) m.push('様式3-2（推薦状）')
    const incomplete = (app.case_reports ?? []).some(cr => !isCaseReportFilled(cr))
    if (incomplete) m.push('自験例報告書（未入力の症例があります）')
  }
  return m
})

const submitApplication = () => {
  if (!confirm('受験申込を提出します。よろしいですか？')) return
  router.post(route('exams.submit', props.exam.id))
}
</script>

<style scoped>
.input-field {
  @apply w-full rounded-md border border-gray-300 px-3 py-2 text-sm
         shadow-sm focus:border-indigo-500 focus:ring-2 focus:ring-indigo-500;
}
</style>
